package Model;

public class Produtomodel {
    public int Cod;
    public String Nome;
    public String Cor;
    public String Tamanho;
    public int Qtd;
    public float ValorDeCusto;
    public float ValorDeVenda;
    public float Lucro;
    public int QtdMinimaEstoque;
    public int QtdMaximaEstoque;
    public String Fornecedor;

    /**
     * @return the Cod
     */
    public int getCod() {
        return Cod;
    }

    /**
     * @param Cod the Cod to set
     */
    public void setCod(int Cod) {
        this.Cod = Cod;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    /**
     * @return the Cor
     */
    public String getCor() {
        return Cor;
    }

    /**
     * @param Cor the Cor to set
     */
    public void setCor(String Cor) {
        this.Cor = Cor;
    }

    /**
     * @return the Tamanho
     */
    public String getTamanho() {
        return Tamanho;
    }

    /**
     * @param Tamanho the Tamanho to set
     */
    public void setTamanho(String Tamanho) {
        this.Tamanho = Tamanho;
    }

    /**
     * @return the ValorDeCusto
     */
    public float getValorDeCusto() {
        return ValorDeCusto;
    }

    /**
     * @param ValorDeCusto the ValorDeCusto to set
     */
    public void setValorDeCusto(float ValorDeCusto) {
        this.ValorDeCusto = ValorDeCusto;
    }

    /**
     * @return the ValorDeVenda
     */
    public float getValorDeVenda() {
        return ValorDeVenda;
    }

    /**
     * @param ValorDeVenda the ValorDeVenda to set
     */
    public void setValorDeVenda(float ValorDeVenda) {
        this.ValorDeVenda = ValorDeVenda;
    }

    /**
     * @return the Lucro
     */
    public float getLucro() {
        return Lucro;
    }

    /**
     * @param Lucro the Lucro to set
     */
    public void setLucro(float Lucro) {
        this.Lucro = Lucro;
    }

    /**
     * @return the QtdMinimaEstoque
     */
    public int getQtdMinimaEstoque() {
        return QtdMinimaEstoque;
    }

    /**
     * @param QtdMinimaEstoque the QtdMinimaEstoque to set
     */
    public void setQtdMinimaEstoque(int QtdMinimaEstoque) {
        this.QtdMinimaEstoque = QtdMinimaEstoque;
    }

    /**
     * @return the QtdMaximaEstoque
     */
    public int getQtdMaximaEstoque() {
        return QtdMaximaEstoque;
    }

    /**
     * @param QtdMaximaEstoque the QtdMaximaEstoque to set
     */
    public void setQtdMaximaEstoque(int QtdMaximaEstoque) {
        this.QtdMaximaEstoque = QtdMaximaEstoque;
    }

    public void getCod(String string) {
        
        
    }

    public void getNome(String string) {
       
    }

    public void getCor(String string) {
        
    }

    public void getTamanho(String string) {
        
    }

    /**
     * @return the Qtd
     */
    public int getQtd() {
        return Qtd;
    }

    /**
     * @param Qtd the Qtd to set
     */
    public void setQtd(int Qtd) {
        this.Qtd = Qtd;
    }

    public void getQtd(int aInt) {
      
    }

    public void getValorDeCusto(float aFloat) {
       
    }

    public void getValorDeVenda(float aFloat) {
      
    }

    public void getQtdMinimaEstoque(int aInt) {
        
    }

    public void getQtdMaximaEstoque(int aInt) {
       
    }

    /**
     * @return the Fornecedor
     */
    public String getFornecedor() {
        return Fornecedor;
    }

    /**
     * @param Fornecedor the Fornecedor to set
     */
    public void setFornecedor(String Fornecedor) {
        this.Fornecedor = Fornecedor;
    }

    public void getFornecedor(String string) {
       
    }
    
}
