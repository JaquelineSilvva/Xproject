
package DAO;

import Model.Produtomodel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;





public class ProdutoDAO {
    private Connection connection;
    
    public ProdutoDAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String DATABASE_URL = "jdbc:mysql://localhost:3306/xproject";
            String usuario = "root";
            String senha = "";
            this.connection = DriverManager.getConnection(DATABASE_URL, usuario, senha);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

public List<Produtomodel> listar() {
 String sql = "SELECT * FROM produto";
        List<Produtomodel> retorno = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();
            while (resultado.next()) {
                Produtomodel produtos = new Produtomodel();
            
                produtos.getCod(resultado.getString("cod"));
                produtos.getNome(resultado.getString("nome"));
                produtos.getCor(resultado.getString("cor"));
                produtos.getTamanho(resultado.getString("tamanho"));
                produtos.getQtd(resultado.getInt("qtddisponivel"));
                produtos.getValorDeCusto(resultado.getFloat("valorcusto"));
                produtos.getValorDeVenda(resultado.getFloat("valorvenda"));
                produtos.getQtdMinimaEstoque(resultado.getInt("qtdminimaestoque"));
                produtos.getQtdMaximaEstoque(resultado.getInt("qtdmaximaestoque"));
                produtos.getFornecedor(resultado.getString("fornecedor"));
                retorno.add(produtos);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            
        }finally{
            
        }
        return retorno;
    }
}
  